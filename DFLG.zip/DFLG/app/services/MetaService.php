<?php

namespace app\services;

use app\models\Meta;
use app\repositories\MetaRepository;
use DateTimeImmutable;

class MetaService
{
    private MetaRepository $repository;
    private TransacaoService $transacaoService;
    private CategoriaService $categoriaService;
    private array $erros = [];

    public function __construct()
    {
        $this->repository = new MetaRepository();
        $this->transacaoService = new TransacaoService();
        $this->categoriaService = new CategoriaService();
    }

    public function getMetas(int $usuarioId): array
    {
        return $this->repository->getMetasPorUsuario($usuarioId);
    }

    public function getMeta(int $id, int $usuarioId)
    {
        return $this->repository->getMeta($id, $usuarioId);
    }

    public function saveMeta(Meta $meta): bool
    {
        if (!$this->validar($meta)) {
            return false;
        }

        return $this->repository->saveMeta($meta);
    }

    public function updateMeta(Meta $meta): bool
    {
        if (!$this->repository->getMeta($meta->getId(), $meta->getUsuarioId())) {
            $this->erros['meta'] = "Meta não encontrada";

            return false;
        }

        if (!$this->validar($meta)) {
            return false;
        }

        return $this->repository->updateMeta($meta);
    }

    // ao excluir a meta, as despesas dos aportes saem junto e o dinheiro volta para o saldo
    public function deleteMeta(int $id, int $usuarioId): bool
    {
        return $this->repository->deleteMeta($id, $usuarioId);
    }

    public function getSaldo(int $usuarioId): float
    {
        return $this->transacaoService->getSaldo($usuarioId);
    }

    // RF 14 (UC-14 inclui UC-07.5): transfere saldo para a meta
    public function aportar(int $metaId, int $usuarioId, float $valor): bool
    {
        $this->erros = [];

        $meta = $this->repository->getMeta($metaId, $usuarioId);

        if (!$meta) {
            $this->erros['meta'] = "Meta não encontrada";

            return false;
        }

        if ($meta->eConcluida()) {
            $this->erros['valor'] = "Esta meta já foi concluída";

            return false;
        }

        $valor = round($valor, 2);
        $faltante = round($meta->getValorAlvo() - $meta->getValorAtual(), 2);
        $saldo = $this->transacaoService->getSaldo($usuarioId);

        if ($valor <= 0) {
            $this->erros['valor'] = "O valor deve ser maior que zero";
        } elseif ($valor > $faltante) {
            $this->erros['valor'] = "O valor não pode passar do que falta para concluir a meta (R$ " . number_format($faltante, 2, ',', '.') . ")";
        } elseif ($valor > $saldo) {
            $this->erros['valor'] = "Saldo insuficiente (saldo disponível: R$ " . number_format($saldo, 2, ',', '.') . ")";
        }

        if (!empty($this->erros)) {
            return false;
        }

        $categoria = $this->categoriaService->getCategoriaPorNome(CategoriaService::CATEGORIA_APORTE_META, 'despesa');

        if (!$categoria) {
            $this->erros['meta'] = "Categoria \"" . CategoriaService::CATEGORIA_APORTE_META . "\" não encontrada";

            return false;
        }

        $descricao = "Aporte na meta: " . $meta->getNomeMeta();

        if (!$this->repository->registrarAporte($metaId, $usuarioId, $valor, $categoria->getId(), $descricao)) {
            $this->erros['valor'] = "Não foi possível registrar o aporte";

            return false;
        }

        return true;
    }

    public function getErros(): array
    {
        return $this->erros;
    }

    private function validar(Meta $meta): bool
    {
        $this->erros = [];

        if ($meta->getValorAlvo() <= 0) {
            $this->erros['valorAlvo'] = "O valor alvo deve ser maior que zero";
        }

        if ($meta->getValorAtual() < 0) {
            $this->erros['valorAtual'] = "O valor atual não pode ser negativo";
        }

        $hoje = new DateTimeImmutable('today');
        $dataLimite = DateTimeImmutable::createFromFormat('Y-m-d', $meta->getDataLimite());

        if (!$dataLimite) {
            $this->erros['dataLimite'] = "Informe uma data limite válida";
        } elseif ($dataLimite->setTime(0, 0) <= $hoje) {
            $this->erros['dataLimite'] = "A data limite deve ser posterior à data de hoje";
        }

        return empty($this->erros);
    }
}